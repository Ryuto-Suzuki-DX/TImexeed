package builders

import (
	"time"

	"timexeed/backend/internal/models"
	"timexeed/backend/internal/modules/user/types"
	"timexeed/backend/internal/results"

	"gorm.io/gorm"
)

type AttendanceDayBuilder interface {
	BuildSearchAttendanceDaysQuery(userID uint, req types.SearchAttendanceDaysRequest) (*gorm.DB, results.Result)
	BuildFindAttendanceDayByUserIDAndWorkDateQuery(userID uint, workDate time.Time) (*gorm.DB, results.Result)
	BuildCreateAttendanceDayModel(
		userID uint,
		req types.UpdateAttendanceDayRequest,
		workDate time.Time,
		planStartAt *time.Time,
		planEndAt *time.Time,
		actualStartAt *time.Time,
		actualEndAt *time.Time,
		actualWorkStatus string,
	) (models.AttendanceDay, results.Result)
	BuildUpdateAttendanceDayModel(
		currentAttendanceDay models.AttendanceDay,
		req types.UpdateAttendanceDayRequest,
		workDate time.Time,
		planStartAt *time.Time,
		planEndAt *time.Time,
		actualStartAt *time.Time,
		actualEndAt *time.Time,
		actualWorkStatus string,
	) (models.AttendanceDay, results.Result)
	BuildDeleteAttendanceDayModel(currentAttendanceDay models.AttendanceDay) (models.AttendanceDay, results.Result)
}

/*
 * 従業員用勤怠Builder
 *
 * 役割：
 * ・Serviceから受け取ったRequestをもとにGORMクエリを作成する
 * ・Serviceから受け取ったRequestをもとにDB保存用Modelを作成する
 * ・Builder内で発生したエラーはBuilderでcode/message/detailsを作って返す
 *
 * 注意：
 * ・DB実行はしない
 * ・Find / Create / Save はRepositoryに任せる
 * ・日付文字列、日時文字列の変換はServiceで行う
 * ・Builderでは変換済みの time.Time / *time.Time を受け取る
 * ・AttendanceDay は申請状態を持たない
 * ・AttendanceDay は画面表示用SystemMessageを持たない
 * ・月次申請状態は MonthlyAttendanceRequest 側で管理する
 * ・画面表示用メッセージは、保存せずに表示時に組み立てる
 * ・予定区分は attendance_types を参照する
 * ・実績状態は constants の固定値を保存する
 * ・日別交通費は AttendanceTransportExpense で管理し、AttendanceDayには保存しない
 */
type attendanceDayBuilder struct {
	db *gorm.DB
}

/*
 * AttendanceDayBuilder生成
 */
func NewAttendanceDayBuilder(db *gorm.DB) AttendanceDayBuilder {
	return &attendanceDayBuilder{db: db}
}

/*
 * 勤怠検索用クエリ作成
 */
func (builder *attendanceDayBuilder) BuildSearchAttendanceDaysQuery(
	userID uint,
	req types.SearchAttendanceDaysRequest,
) (*gorm.DB, results.Result) {
	if userID == 0 {
		return nil, results.BadRequest(
			"BUILD_SEARCH_ATTENDANCE_DAYS_QUERY_INVALID_USER_ID",
			"勤怠検索条件の作成に失敗しました",
			map[string]any{"userId": userID},
		)
	}

	if req.TargetYear <= 0 {
		return nil, results.BadRequest(
			"BUILD_SEARCH_ATTENDANCE_DAYS_QUERY_INVALID_TARGET_YEAR",
			"勤怠検索条件の作成に失敗しました",
			map[string]any{"targetYear": req.TargetYear},
		)
	}

	if req.TargetMonth < 1 || req.TargetMonth > 12 {
		return nil, results.BadRequest(
			"BUILD_SEARCH_ATTENDANCE_DAYS_QUERY_INVALID_TARGET_MONTH",
			"勤怠検索条件の作成に失敗しました",
			map[string]any{"targetMonth": req.TargetMonth},
		)
	}

	startDate := time.Date(req.TargetYear, time.Month(req.TargetMonth), 1, 0, 0, 0, 0, time.Local)
	endDate := startDate.AddDate(0, 1, 0)

	query := builder.db.
		Model(&models.AttendanceDay{}).
		Preload("PlanAttendanceType").
		Where("user_id = ?", userID).
		Where("work_date >= ?", startDate).
		Where("work_date < ?", endDate).
		Where("is_deleted = ?", false).
		Order("work_date ASC").
		Order("id ASC")

	return query, results.OK(
		nil,
		"BUILD_SEARCH_ATTENDANCE_DAYS_QUERY_SUCCESS",
		"",
		nil,
	)
}

/*
 * ユーザーID + 対象日で勤怠1件取得用クエリ作成
 */
func (builder *attendanceDayBuilder) BuildFindAttendanceDayByUserIDAndWorkDateQuery(
	userID uint,
	workDate time.Time,
) (*gorm.DB, results.Result) {
	if userID == 0 {
		return nil, results.BadRequest(
			"BUILD_FIND_ATTENDANCE_DAY_QUERY_INVALID_USER_ID",
			"勤怠取得条件の作成に失敗しました",
			map[string]any{"userId": userID},
		)
	}

	if workDate.IsZero() {
		return nil, results.BadRequest(
			"BUILD_FIND_ATTENDANCE_DAY_QUERY_EMPTY_WORK_DATE",
			"勤怠取得条件の作成に失敗しました",
			nil,
		)
	}

	query := builder.db.
		Model(&models.AttendanceDay{}).
		Preload("PlanAttendanceType").
		Where("user_id = ?", userID).
		Where("work_date = ?", workDate).
		Where("is_deleted = ?", false)

	return query, results.OK(
		nil,
		"BUILD_FIND_ATTENDANCE_DAY_QUERY_SUCCESS",
		"",
		nil,
	)
}

/*
 * 勤怠作成用Model作成
 */
func (builder *attendanceDayBuilder) BuildCreateAttendanceDayModel(
	userID uint,
	req types.UpdateAttendanceDayRequest,
	workDate time.Time,
	planStartAt *time.Time,
	planEndAt *time.Time,
	actualStartAt *time.Time,
	actualEndAt *time.Time,
	actualWorkStatus string,
) (models.AttendanceDay, results.Result) {
	if userID == 0 {
		return models.AttendanceDay{}, results.BadRequest(
			"BUILD_CREATE_ATTENDANCE_DAY_MODEL_INVALID_USER_ID",
			"勤怠作成データの作成に失敗しました",
			map[string]any{"userId": userID},
		)
	}

	if workDate.IsZero() {
		return models.AttendanceDay{}, results.BadRequest(
			"BUILD_CREATE_ATTENDANCE_DAY_MODEL_EMPTY_WORK_DATE",
			"勤怠作成データの作成に失敗しました",
			nil,
		)
	}

	if req.PlanAttendanceTypeID == 0 {
		return models.AttendanceDay{}, results.BadRequest(
			"BUILD_CREATE_ATTENDANCE_DAY_MODEL_EMPTY_PLAN_ATTENDANCE_TYPE_ID",
			"勤怠作成データの作成に失敗しました",
			nil,
		)
	}

	if actualWorkStatus == "" {
		return models.AttendanceDay{}, results.BadRequest(
			"BUILD_CREATE_ATTENDANCE_DAY_MODEL_EMPTY_ACTUAL_WORK_STATUS",
			"勤怠作成データの作成に失敗しました",
			nil,
		)
	}

	attendanceDay := models.AttendanceDay{
		UserID:                  userID,
		WorkDate:                workDate,
		PlanAttendanceTypeID:    req.PlanAttendanceTypeID,
		ActualWorkStatus:        actualWorkStatus,
		PlanStartAt:             planStartAt,
		PlanEndAt:               planEndAt,
		ActualStartAt:           actualStartAt,
		ActualEndAt:             actualEndAt,
		ScheduledWorkMinutes:    req.ScheduledWorkMinutes,
		RemoteWorkAllowanceFlag: req.RemoteWorkAllowanceFlag,
		IsDeleted:               false,
	}

	return attendanceDay, results.OK(
		nil,
		"BUILD_CREATE_ATTENDANCE_DAY_MODEL_SUCCESS",
		"",
		nil,
	)
}

/*
 * 勤怠更新用Model作成
 */
func (builder *attendanceDayBuilder) BuildUpdateAttendanceDayModel(
	currentAttendanceDay models.AttendanceDay,
	req types.UpdateAttendanceDayRequest,
	workDate time.Time,
	planStartAt *time.Time,
	planEndAt *time.Time,
	actualStartAt *time.Time,
	actualEndAt *time.Time,
	actualWorkStatus string,
) (models.AttendanceDay, results.Result) {
	if currentAttendanceDay.ID == 0 {
		return models.AttendanceDay{}, results.BadRequest(
			"BUILD_UPDATE_ATTENDANCE_DAY_MODEL_EMPTY_CURRENT_ATTENDANCE_DAY",
			"勤怠更新データの作成に失敗しました",
			nil,
		)
	}

	if workDate.IsZero() {
		return models.AttendanceDay{}, results.BadRequest(
			"BUILD_UPDATE_ATTENDANCE_DAY_MODEL_EMPTY_WORK_DATE",
			"勤怠更新データの作成に失敗しました",
			nil,
		)
	}

	if req.PlanAttendanceTypeID == 0 {
		return models.AttendanceDay{}, results.BadRequest(
			"BUILD_UPDATE_ATTENDANCE_DAY_MODEL_EMPTY_PLAN_ATTENDANCE_TYPE_ID",
			"勤怠更新データの作成に失敗しました",
			nil,
		)
	}

	if actualWorkStatus == "" {
		return models.AttendanceDay{}, results.BadRequest(
			"BUILD_UPDATE_ATTENDANCE_DAY_MODEL_EMPTY_ACTUAL_WORK_STATUS",
			"勤怠更新データの作成に失敗しました",
			nil,
		)
	}

	currentAttendanceDay.WorkDate = workDate
	currentAttendanceDay.PlanAttendanceTypeID = req.PlanAttendanceTypeID
	currentAttendanceDay.ActualWorkStatus = actualWorkStatus
	currentAttendanceDay.PlanStartAt = planStartAt
	currentAttendanceDay.PlanEndAt = planEndAt
	currentAttendanceDay.ActualStartAt = actualStartAt
	currentAttendanceDay.ActualEndAt = actualEndAt
	currentAttendanceDay.ScheduledWorkMinutes = req.ScheduledWorkMinutes
	currentAttendanceDay.RemoteWorkAllowanceFlag = req.RemoteWorkAllowanceFlag

	return currentAttendanceDay, results.OK(
		nil,
		"BUILD_UPDATE_ATTENDANCE_DAY_MODEL_SUCCESS",
		"",
		nil,
	)
}

/*
 * 勤怠論理削除用Model作成
 */
func (builder *attendanceDayBuilder) BuildDeleteAttendanceDayModel(
	currentAttendanceDay models.AttendanceDay,
) (models.AttendanceDay, results.Result) {
	if currentAttendanceDay.ID == 0 {
		return models.AttendanceDay{}, results.BadRequest(
			"BUILD_DELETE_ATTENDANCE_DAY_MODEL_EMPTY_CURRENT_ATTENDANCE_DAY",
			"勤怠削除データの作成に失敗しました",
			nil,
		)
	}

	now := time.Now()

	currentAttendanceDay.IsDeleted = true
	currentAttendanceDay.DeletedAt = &now

	return currentAttendanceDay, results.OK(
		nil,
		"BUILD_DELETE_ATTENDANCE_DAY_MODEL_SUCCESS",
		"",
		nil,
	)
}
