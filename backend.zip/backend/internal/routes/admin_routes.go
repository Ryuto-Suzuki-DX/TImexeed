package routes

import (
	"context"

	"timexeed/backend/internal/modules/admin/builders"
	"timexeed/backend/internal/modules/admin/controllers"
	"timexeed/backend/internal/modules/admin/repositories"
	"timexeed/backend/internal/modules/admin/services"
	"timexeed/backend/internal/storage"

	"timexeed/backend/internal/middlewares"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

/*
 * 〇 管理者用APIルート登録
 *
 * 管理者だけが使うAPIをここにまとめる。
 *
 * 重要：
 * 	管理者APIと従業員APIは完全に分離する。
 * 	従業員画面から使うAPIはここには書かない。
 *
 * ルール：
 * 	URLにIDを載せない。
 * 	targetUserId や attendanceId などは request body で受け取る。
 */
func RegisterAdminRoutes(r *gin.Engine, db *gorm.DB) {

	// Google Drive
	//
	// 注意：
	// ・環境変数が未設定でもアプリ起動自体は止めない
	// ・未設定の場合、Drive連携系Service側でエラーを返す
	googleDriveService, _ := storage.NewGoogleDriveServiceFromEnv(context.Background())

	// 所属
	departmentBuilder := builders.NewDepartmentBuilder(db)
	departmentRepository := repositories.NewDepartmentRepository(db)
	departmentService := services.NewDepartmentService(departmentBuilder, departmentRepository)
	departmentController := controllers.NewDepartmentController(departmentService)

	// ユーザー
	userBuilder := builders.NewUserBuilder(db)
	userRepository := repositories.NewUserRepository(db)
	userService := services.NewUserService(userBuilder, userRepository)
	userController := controllers.NewUserController(userService)

	// 共有資料Driveフォルダ
	sharedDocumentDriveFolderBuilder := builders.NewSharedDocumentDriveFolderBuilder(db)
	sharedDocumentDriveFolderRepository := repositories.NewSharedDocumentDriveFolderRepository(db)
	sharedDocumentDriveFolderService := services.NewSharedDocumentDriveFolderService(sharedDocumentDriveFolderBuilder, sharedDocumentDriveFolderRepository, googleDriveService)
	sharedDocumentDriveFolderController := controllers.NewSharedDocumentDriveFolderController(sharedDocumentDriveFolderService)

	// ユーザー給与詳細
	userSalaryDetailBuilder := builders.NewUserSalaryDetailBuilder(db)
	userSalaryDetailRepository := repositories.NewUserSalaryDetailRepository(db)
	userSalaryDetailService := services.NewUserSalaryDetailService(userSalaryDetailBuilder, userSalaryDetailRepository)
	userSalaryDetailController := controllers.NewUserSalaryDetailController(userSalaryDetailService)

	// 手当種別マスター・月次手当
	allowanceBuilder := builders.NewAllowanceBuilder(db)
	allowanceRepository := repositories.NewAllowanceRepository(db)
	allowanceService := services.NewAllowanceService(db, allowanceBuilder, allowanceRepository)
	allowanceController := controllers.NewAllowanceController(allowanceService)

	// 勤怠区分マスタ
	attendanceTypeBuilder := builders.NewAttendanceTypeBuilder(db)
	attendanceTypeRepository := repositories.NewAttendanceTypeRepository(db)
	attendanceTypeService := services.NewAttendanceTypeService(attendanceTypeBuilder, attendanceTypeRepository)
	attendanceTypeController := controllers.NewAttendanceTypeController(attendanceTypeService)

	// お知らせ
	notificationBuilder := builders.NewNotificationBuilder(db)
	notificationRepository := repositories.NewNotificationRepository(db)
	notificationService := services.NewNotificationService(notificationBuilder, notificationRepository)
	notificationController := controllers.NewNotificationController(notificationService)

	// 月次勤怠申請
	monthlyAttendanceRequestBuilder := builders.NewMonthlyAttendanceRequestBuilder(db)
	monthlyAttendanceRequestRepository := repositories.NewMonthlyAttendanceRequestRepository(db)
	monthlyAttendanceRequestService := services.NewMonthlyAttendanceRequestService(monthlyAttendanceRequestBuilder, monthlyAttendanceRequestRepository, notificationService)
	monthlyAttendanceRequestController := controllers.NewMonthlyAttendanceRequestController(monthlyAttendanceRequestService)

	// 勤怠
	attendanceDayBuilder := builders.NewAttendanceDayBuilder(db)
	attendanceDayRepository := repositories.NewAttendanceDayRepository(db)
	attendanceDayService := services.NewAttendanceDayService(attendanceDayBuilder, attendanceDayRepository, attendanceTypeRepository, monthlyAttendanceRequestBuilder, monthlyAttendanceRequestRepository)
	attendanceDayController := controllers.NewAttendanceDayController(attendanceDayService)

	// 日別交通費
	attendanceTransportExpenseBuilder := builders.NewAttendanceTransportExpenseBuilder(db)
	attendanceTransportExpenseRepository := repositories.NewAttendanceTransportExpenseRepository(db)
	attendanceTransportExpenseService := services.NewAttendanceTransportExpenseService(
		attendanceTransportExpenseBuilder,
		attendanceTransportExpenseRepository,
		attendanceDayBuilder,
		attendanceDayRepository,
	)
	attendanceTransportExpenseController := controllers.NewAttendanceTransportExpenseController(attendanceTransportExpenseService)

	// 休憩
	attendanceBreakBuilder := builders.NewAttendanceBreakBuilder(db)
	attendanceBreakRepository := repositories.NewAttendanceBreakRepository(db)
	attendanceBreakService := services.NewAttendanceBreakService(attendanceBreakBuilder, attendanceBreakRepository, attendanceDayBuilder, attendanceDayRepository, monthlyAttendanceRequestBuilder, monthlyAttendanceRequestRepository)
	attendanceBreakController := controllers.NewAttendanceBreakController(attendanceBreakService)

	// 月次通勤定期
	monthlyCommuterPassBuilder := builders.NewMonthlyCommuterPassBuilder(db)
	monthlyCommuterPassRepository := repositories.NewMonthlyCommuterPassRepository(db)
	monthlyCommuterPassService := services.NewMonthlyCommuterPassService(monthlyCommuterPassBuilder, monthlyCommuterPassRepository, monthlyAttendanceRequestBuilder, monthlyAttendanceRequestRepository)
	monthlyCommuterPassController := controllers.NewMonthlyCommuterPassController(monthlyCommuterPassService)

	// 有給使用日
	paidLeaveUsageBuilder := builders.NewPaidLeaveUsageBuilder(db)
	paidLeaveUsageRepository := repositories.NewPaidLeaveUsageRepository(db)
	paidLeaveUsageService := services.NewPaidLeaveUsageService(paidLeaveUsageBuilder, paidLeaveUsageRepository)
	paidLeaveUsageController := controllers.NewPaidLeaveUsageController(paidLeaveUsageService)

	// 祝日
	holidayDateBuilder := builders.NewHolidayDateBuilder(db)
	holidayDateRepository := repositories.NewHolidayDateRepository(db)
	holidayDateService := services.NewHolidayDateService(holidayDateBuilder, holidayDateRepository)
	holidayDateController := controllers.NewHolidayDateController(holidayDateService)

	// 外部ストレージリンク管理
	externalStorageLinkBuilder := builders.NewExternalStorageLinkBuilder(db)
	externalStorageLinkRepository := repositories.NewExternalStorageLinkRepository(db)
	externalStorageLinkService := services.NewExternalStorageLinkService(externalStorageLinkBuilder, externalStorageLinkRepository)
	externalStorageLinkController := controllers.NewExternalStorageLinkController(externalStorageLinkService)

	// 個人情報Driveフォルダ
	personalInformationDriveFolderBuilder := builders.NewPersonalInformationDriveFolderBuilder(db)
	personalInformationDriveFolderRepository := repositories.NewPersonalInformationDriveFolderRepository(db)
	personalInformationDriveFolderService := services.NewPersonalInformationDriveFolderService(personalInformationDriveFolderBuilder, personalInformationDriveFolderRepository, googleDriveService)
	personalInformationDriveFolderController := controllers.NewPersonalInformationDriveFolderController(personalInformationDriveFolderService)

	// 経費
	expenseBuilder := builders.NewExpenseBuilder(db)
	expenseRepository := repositories.NewExpenseRepository(db)
	expenseService := services.NewExpenseService(expenseBuilder, expenseRepository, externalStorageLinkRepository, googleDriveService)
	expenseController := controllers.NewExpenseController(expenseService)

	// お知らせ自動リマインド
	notificationReminderBuilder := builders.NewNotificationReminderBuilder(db)
	notificationReminderRepository := repositories.NewNotificationReminderRepository(db)
	notificationReminderService := services.NewNotificationReminderService(notificationReminderBuilder, notificationReminderRepository)
	notificationReminderController := controllers.NewNotificationReminderController(notificationReminderService)

	// 月次勤怠全体保存
	monthlyAttendanceSaveService := services.NewMonthlyAttendanceSaveService(
		attendanceDayService,
		attendanceTransportExpenseService,
		attendanceBreakService,
		monthlyCommuterPassService,
		attendanceTypeService,
		paidLeaveUsageService,
	)
	monthlyAttendanceSaveController := controllers.NewMonthlyAttendanceSaveController(monthlyAttendanceSaveService)

	// 月次勤怠集計CSV出力
	monthlyAttendanceSummaryExportBuilder := builders.NewMonthlyAttendanceSummaryExportBuilder(db)
	monthlyAttendanceSummaryExportRepository := repositories.NewMonthlyAttendanceSummaryExportRepository(db)
	monthlyAttendanceSummaryExportService := services.NewMonthlyAttendanceSummaryExportService(monthlyAttendanceSummaryExportBuilder, monthlyAttendanceSummaryExportRepository)
	monthlyAttendanceSummaryExportController := controllers.NewMonthlyAttendanceSummaryExportController(monthlyAttendanceSummaryExportService)

	// 勤怠リアルタイムイベント
	attendanceRealtimeEventBuilder := builders.NewAttendanceRealtimeEventBuilder(db)
	attendanceRealtimeEventRepository := repositories.NewAttendanceRealtimeEventRepository(db)
	attendanceRealtimeEventService := services.NewAttendanceRealtimeEventService(attendanceRealtimeEventBuilder, attendanceRealtimeEventRepository)
	attendanceRealtimeEventController := controllers.NewAttendanceRealtimeEventController(attendanceRealtimeEventService)

	admin := r.Group("/admin")

	admin.Use(
		middlewares.AuthMiddleware(),
		middlewares.ApiOperationLogMiddleware(db),
		middlewares.AdminMiddleware(),
	)

	{
		// 所属
		admin.POST("/departments/search", departmentController.SearchDepartments)
		admin.POST("/departments/detail", departmentController.GetDepartmentDetail)
		admin.POST("/departments/create", departmentController.CreateDepartment)
		admin.POST("/departments/update", departmentController.UpdateDepartment)
		admin.POST("/departments/delete", departmentController.DeleteDepartment)

		// ユーザー
		admin.POST("/users/search", userController.SearchUsers)
		admin.POST("/users/search-business-targets", userController.SearchBusinessTargetUsers)
		admin.POST("/users/detail", userController.GetUserDetail)
		admin.POST("/users/create", userController.CreateUser)
		admin.POST("/users/update", userController.UpdateUser)
		admin.POST("/users/delete", userController.DeleteUser)

		// 共有資料Driveフォルダ
		sharedDocumentDriveFolders := admin.Group("/shared-document-drive-folders")
		{
			sharedDocumentDriveFolders.POST("/search", sharedDocumentDriveFolderController.SearchSharedDocumentDriveFolders)
			sharedDocumentDriveFolders.POST("/detail", sharedDocumentDriveFolderController.DetailSharedDocumentDriveFolder)
			sharedDocumentDriveFolders.POST("/create", sharedDocumentDriveFolderController.CreateSharedDocumentDriveFolder)
			sharedDocumentDriveFolders.POST("/update", sharedDocumentDriveFolderController.UpdateSharedDocumentDriveFolder)
			sharedDocumentDriveFolders.POST("/delete", sharedDocumentDriveFolderController.DeleteSharedDocumentDriveFolder)
			sharedDocumentDriveFolders.POST("/sync", sharedDocumentDriveFolderController.SyncSharedDocumentDriveFolder)
		}

		// ユーザー給与詳細
		admin.POST("/user-salary-details/search", userSalaryDetailController.SearchUserSalaryDetails)
		admin.POST("/user-salary-details/get", userSalaryDetailController.GetUserSalaryDetail)
		admin.POST("/user-salary-details/create", userSalaryDetailController.CreateUserSalaryDetail)
		admin.POST("/user-salary-details/update", userSalaryDetailController.UpdateUserSalaryDetail)
		admin.POST("/user-salary-details/delete", userSalaryDetailController.DeleteUserSalaryDetail)

		// 手当種別マスター
		admin.POST("/allowance-types/search", allowanceController.SearchAllowanceTypes)
		admin.POST("/allowance-types/detail", allowanceController.GetAllowanceTypeDetail)
		admin.POST("/allowance-types/create", allowanceController.CreateAllowanceType)
		admin.POST("/allowance-types/update", allowanceController.UpdateAllowanceType)
		admin.POST("/allowance-types/delete", allowanceController.DeleteAllowanceType)

		// 月次手当
		admin.POST("/monthly-allowances/search", allowanceController.SearchMonthlyAllowances)
		admin.POST("/monthly-allowances/detail", allowanceController.GetMonthlyAllowanceDetail)
		admin.POST("/monthly-allowances/create", allowanceController.CreateMonthlyAllowance)
		admin.POST("/monthly-allowances/update", allowanceController.UpdateMonthlyAllowance)
		admin.POST("/monthly-allowances/delete", allowanceController.DeleteMonthlyAllowance)

		// 勤怠区分マスタ（検索のみ）
		admin.POST("/attendance-types/search", attendanceTypeController.SearchAttendanceTypes)

		// 月次勤怠申請
		admin.POST("/monthly-attendance-requests/search", monthlyAttendanceRequestController.SearchMonthlyAttendanceRequests)
		admin.POST("/monthly-attendance-requests/status", monthlyAttendanceRequestController.GetMonthlyAttendanceRequestStatus)
		admin.POST("/monthly-attendance-requests/submit", monthlyAttendanceRequestController.SubmitMonthlyAttendanceRequest)
		admin.POST("/monthly-attendance-requests/cancel", monthlyAttendanceRequestController.CancelMonthlyAttendanceRequest)
		admin.POST("/monthly-attendance-requests/approve", monthlyAttendanceRequestController.ApproveMonthlyAttendanceRequest)
		admin.POST("/monthly-attendance-requests/reject", monthlyAttendanceRequestController.RejectMonthlyAttendanceRequest)

		// 勤怠
		admin.POST("/attendance-days/search", attendanceDayController.SearchAttendanceDays)

		// 日別交通費
		admin.POST("/attendance-transport-expenses/search", attendanceTransportExpenseController.SearchAttendanceTransportExpenses)

		// 休憩
		admin.POST("/attendance-breaks/search", attendanceBreakController.SearchAttendanceBreaks)

		// 月次通勤定期
		admin.POST("/monthly-commuter-passes/search", monthlyCommuterPassController.SearchMonthlyCommuterPass)

		// 有給使用日
		admin.POST("/paid-leave-usages/search", paidLeaveUsageController.SearchPaidLeaveUsages)
		admin.POST("/paid-leave-usages/balance", paidLeaveUsageController.GetPaidLeaveBalance)
		admin.POST("/paid-leave-usages/required-use-warnings", paidLeaveUsageController.SearchPaidLeaveRequiredUseWarnings)
		admin.POST("/paid-leave-usages/create", paidLeaveUsageController.CreatePaidLeaveUsage)
		admin.POST("/paid-leave-usages/update", paidLeaveUsageController.UpdatePaidLeaveUsage)
		admin.POST("/paid-leave-usages/delete", paidLeaveUsageController.DeletePaidLeaveUsage)

		// 祝日
		admin.POST("/holiday-dates/import", holidayDateController.ImportHolidayDates)
		admin.POST("/holiday-dates/search", holidayDateController.SearchHolidayDates)

		// 外部ストレージリンク
		admin.POST("/external-storage-links/search", externalStorageLinkController.SearchExternalStorageLinks)
		admin.POST("/external-storage-links/update", externalStorageLinkController.UpdateExternalStorageLink)

		// 個人情報ファイル
		admin.POST("/personal-information-drive-folders/search", personalInformationDriveFolderController.SearchPersonalInformationDriveFolders)
		admin.POST("/personal-information-drive-folders/sync", personalInformationDriveFolderController.SyncPersonalInformationDriveFolder)
		admin.POST("/personal-information-drive-folders/view", personalInformationDriveFolderController.ViewPersonalInformationDriveFolder)

		// 経費
		admin.POST("/expenses/search", expenseController.SearchExpenses)
		admin.POST("/expenses/detail", expenseController.GetExpenseDetail)
		admin.POST("/expenses/create", expenseController.CreateExpense)
		admin.POST("/expenses/update", expenseController.UpdateExpense)
		admin.POST("/expenses/delete", expenseController.DeleteExpense)
		admin.POST("/expenses/receipt/view", expenseController.ViewExpenseReceipt)
		admin.POST("/expenses/export", expenseController.ExportExpenses)

		// お知らせ
		admin.POST("/notifications/search", notificationController.SearchNotifications)
		admin.POST("/notifications/read", notificationController.ReadNotification)
		admin.POST("/notifications/unread-count", notificationController.CountUnreadNotifications)
		admin.POST("/notifications/create-for-all-users", notificationController.CreateNotificationForAllUsers)
		admin.POST("/notifications/delete", notificationController.DeleteNotification)
		admin.POST("/notifications/read-status", notificationController.GetNotificationReadStatus)

		// お知らせ自動リマインド
		admin.POST("/notification-reminders/search", notificationReminderController.SearchNotificationReminders)
		admin.POST("/notification-reminders/create", notificationReminderController.CreateNotificationReminder)
		admin.POST("/notification-reminders/update", notificationReminderController.UpdateNotificationReminder)
		admin.POST("/notification-reminders/delete", notificationReminderController.DeleteNotificationReminder)
		admin.POST("/notification-reminders/toggle-enabled", notificationReminderController.ToggleNotificationReminderEnabled)

		// 勤怠リアルタイムイベント
		admin.POST("/attendance-realtime-events/search", attendanceRealtimeEventController.SearchAttendanceRealtimeEvents)

		// 月次勤怠全体保存（勤怠・休憩・月次通勤定期）
		admin.POST("/monthly-attendances/update", monthlyAttendanceSaveController.UpdateMonthlyAttendance)

		// 月次勤怠集計CSV出力
		admin.POST("/monthly-attendance-summary-exports/export", monthlyAttendanceSummaryExportController.ExportMonthlyAttendanceSummaryCsv)
	}
}
